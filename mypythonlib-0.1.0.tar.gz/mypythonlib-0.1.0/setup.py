
from setuptools import find_packages, setup


setup(
    name= 'mypythonlib',
    packages= find_packages(),
    version= '0.1.0',
    description= 'My first python library',
    author= 'Sílvia Santos Martins',
    license= 'MIT',
    install_requires= [],

)


