import os
import shutil

class Directory:
    def __init__(self) -> None:
        pass

    def get_directory(self) -> str:

        """ Retorna o caminho do diretório padrão
            -> exemplo.: 
                a = Directory().get_directory()
        """

        try:
            project_path = os.getcwd()

            return project_path
        
        except Exception as e:
            return (f'Error: {e}')
        
    def create_folder(self, foldername:str, directory:str) -> str:

        """ Cria a pasta no diretorio informado
            -> exemplo.: 
                a = Directory().create_folder('TESTE', 'C:\\Users\\User\\MyPythonLibrary')

        """

        try:
            new_folder = f'{directory}\\{foldername}'
            os.mkdir(new_folder)

            return new_folder
        except Exception as e:
            return (f'Error: {e}')
        
    def create_venv(self, name_venv:str) ->None:

        """ Cria uma venv
            -> exemplo.: 
                a = Directory().create_venv('My-venv') 
        """
        try:
            os.system(f'python -m venv {name_venv}')
        
            return True
        except Exception as e:
            return (f'Error: {e}')

    def command_cmd(self, command_cmd:str) ->None:

        """ Executa um comando no cmd.
            -> exemplo.: 
                a = Directory().command_cmd('ping www.google.com.br')
        """
        try:
            os.system(command_cmd)
        
            return True
        except Exception as e:
            return (f'Error: {e}')

    def list_all_directory(self,directory:str) -> list:
        """ Lista todos os arquivos do diretório.
            -> exemplo.: 
                a = Directory().list_all_directory('C:\\Users\\User\\MyPythonLibrary')
        """
        try:
            list_all = []

            with os.scandir(directory) as entries:
                for entry in entries:
                    list_all.append(entry.name)
        
            return list_all
        except Exception as e:
            return (f'Error: {e}')
    
    def list_all_files_directory(self,directory:str) -> list:
        """ Lista todos os arquivos do diretório.
            -> exemplo.: 
                a = Directory().list_all_directory('C:\\Users\\User\\MyPythonLibrary')
        """
        try:
            list_all_files = []

            with os.scandir(directory) as entries:
                for entry in entries:
                    if entry.is_file():
                        list_all_files.append(entry.name)
        
            return list_all_files
        except Exception as e:
            return (f'Error: {e}')


class Files:
    def __init__(self) -> None:
        pass

    def create_file(self, filename:str, pathfolder:str)-> bool:

        """ Cria o arquivo na pasta informada. 
            -> exemplo.: 
                a = Files().create_file('teste.txt', 'C:\\Users\\User\\MyPythonLibrary') 
        """
        
        try:
            new_file = os.path.join(pathfolder, filename)
            file = open(new_file, 'x')
            file.close()

            return True
        except Exception as e:
            return (f'Error: {e}')
        
    def delete_file(self, directory_file_for_delete:str) -> bool:
        """ Deleta o arquivo desejado, infomando o seu caminho completo. 
            Obs.: Se o arquivo possui dados críticos recomendo fazer uma cópia antes.
            -> exemplo.: 
                a = Files().delete_file('C:\\Users\\User\\MyPythonLibrary\\filename.txt')
        """
        try:
            file = os.path.exists(directory_file_for_delete)
            if file:
                os.unlink(directory_file_for_delete)
        
            return file
        except Exception as e:
            return (f'Error: {e}')

    def copy_file(self,file:str, path_filecopy:str) -> bool:
        """ Copia o arquivo para o local informado.
            -> exemplo.: 
                a = Files().copy_file('C:\\Users\\User\\MyPythonLibrary\\filename.txt','C:\\Users\\User\\MyDocs\\filename.txt')
        """
        try:
            file_exist = os.path.exists(path_filecopy)
            if file_exist == False:
                shutil.copy(file, path_filecopy)
                return True
            else:
                return False
        
        except Exception as e:
            return (f'Error: {e}')
    
    def move_file(self,file:str, path_filemove:str) -> bool:
        """ Move o arquivo para o local informado.
            -> exemplo.: 
                a = Files().move_file('C:\\Users\\User\\MyPythonLibrary\\filename.txt','C:\\Users\\User\\MyDocs\\filename.txt')
        """
        try:
            file_exist = os.path.exists(path_filemove)
            if file_exist == False:
                shutil.move(file, path_filemove)
                return True
            else:
                return False
        
        except Exception as e:
            return (f'Error: {e}')
    
 
class Web:
    def __init__(self) -> None:
        pass

class DataBase:
    def __init__(self) -> None:
        pass

class APIs:
    def __init__(self) -> None:
        pass

class Browser:
    def __init__(self) -> None:
        pass

class Date:
    def __init__(self) -> None:
        pass